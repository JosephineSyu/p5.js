/*
 * @name Input and Button
 * @arialabel “What is your name?” is written in the top left of the window with a text input box and a submit button under. After inputting text and submitting, the text submitted is generated multiple times to cover the background in a random formation in various shades of cyan.
 * @description Input text and click the button to see it affect the the canvas.
 */
let input, button, greeting;
let imgYes, imgNo; 
function preload() {
  imgYES = loadImage('https://raw.githubusercontent.com/JosephineSyu/ImageHosting/main/Blue%20Melon%20Soda.png');
  imgNO = loadImage('https://raw.githubusercontent.com/JosephineSyu/ImageHosting/main/Grey%20Melon%20Soda.png');

}

function setup() {
  // create canvas
  createCanvas(710, 400);

  input = createInput();
  input.position(20, 87.5);

  button = createButton('Go ⋆˙⟡');
  button.position(input.x + input.width, 87.5);
  button.mousePressed(greet);

  greeting = createElement('h2', 'Do you like Melon Soda?');
  greeting.position(20, 5);
  greeting.style('color', '#39FF14');

  textAlign(CENTER);
  textSize(50);
  
  greeting = createElement('h2', 'Yes or No?');
  greeting.position(20, 35);
  greeting.style('font-size', '20px');
  greeting.style('color', '#39FF14');

  textAlign(CENTER);
  textSize(35);
  
  imgYES = loadImage('https://raw.githubusercontent.com/JosephineSyu/ImageHosting/main/Blue%20Melon%20Soda.png');
  imgNO = loadImage('https://raw.githubusercontent.com/JosephineSyu/ImageHosting/main/Grey%20Melon%20Soda.png');

}

function greet() {
  const answer = input.value().toLowerCase();
  input.value('');
  
   clear();
  
  if (answer === 'yes') {
    greeting.html('Yay! Have some blue raspberry melon soda!'); 
  for (let i = 0; i < 200; i++) {
    push();
    fill(random(255), 255, 255);
    translate(random(width), random(height));
    rotate(random(2 * PI));
    image(imgYES, 0, 0, 50, 50);
    pop();
  }
} else if (answer === 'no') {
  greeting.html('Awe (• ᴖ •｡ ) That\'s too Bad ...');
    for (let i = 0; i < 200; i++) {
      push();
      fill(random(255), 255, 255);
      translate(random(width), random(height));
      rotate(random(2 * PI));
      image(imgNO, 0, 0, 50, 50);
      pop();
    }
} else {
  greeting.html('( ˶°ㅁ°) !! Please answer with "Yes" or "No"');
  input.value('');
  }
}
